<?php

// A domain class to demonstrate RESTful API
class Animal
{

    private $animals = array(
        1 => 'Sapi',
        2 => 'Kerbau',
        3 => 'Kucing',
        4 => 'Ayam',
        5 => 'Kuda',
        6 => 'Domba'
    );

    public function getAllAnimal()
    {
        return $this->animals;
    }

    public function getAnimal($id)
    {
        $animal = array($id => ($this->animals[$id]) ? $this->animals[$id] : $this->animals[1]);
        return $animal;
    }
}
