<?php

/*
  404 => 'Not Found'
  200 => 'OK'
*/

require_once("Animal.php");

class AnimalRestHandler
{
    function getAllAnimals()
    {
        $animal = new Animal();
        $rawData = $animal->getAllAnimal();

        if (empty($rawData)) {
            $statusCode = 404;
            $rawData = array('error' => 'No animals found');
        } else {
            $statusCode = 200;
        }

        $response = json_encode($rawData);
        echo $response;
    }

    public function getAnimal($id)
    {
        $animal = new Animal();
        $rawData = $animal->getAnimal($id);

        if (empty($rawData)) {
            $statusCode = 404;
            $rawData = array('error' => 'No animals found');
        } else {
            $statusCode = 200;
        }

        $response = json_encode($rawData);
        echo $response;
    }
}
