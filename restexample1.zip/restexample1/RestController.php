<?php

require_once("AnimalRestHandler.php");

$view = "";
if (isset($_GET["view"]))
    $view = $_GET["view"];

switch ($view) {
    case "all":
        $animalRestHandler = new AnimalRestHandler();
        $animalRestHandler->getAllAnimals();
        break;
    case "single":
        $animalRestHandler = new AnimalRestHandler();
        $animalRestHandler->getAnimal($_GET["id"]);
        break;
    case "":
        // 404 : Not Found
        break;
}
