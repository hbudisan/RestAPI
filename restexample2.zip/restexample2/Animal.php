<?php

require_once("dbcontroller.php");

class Animal
{
    private $animals = array();
    public function getAllAnimal()
    {
        $query = 'SELECT * FROM animals';
        $dbcontroller = new DBController();
        $this->animals = $dbcontroller->executeSelectQuery($query);
        return $this->animals;
    }

    public function addAnimal()
    {
        if (isset($_POST['name'])) {
            $name = $_POST['name'];
            $query = "insert into animals(name) values ('" . $name . "')";
            $dbcontroller = new DBController();
            $result = $dbcontroller->executeQuery($query);
            if ($result != 0) {
                $result = array('success' => 1);
                return $result;
            }
        }
    }

    public function editAnimal()
    {
        if (isset($_POST['name']) && isset($_GET['id'])) {
            $name = $_POST['name'];
            $query = "update animals set name = '" . $name
                . "' where id =" . $_GET['id'];
        }
        $dbcontroller = new DBController();
        $result = $dbcontroller->executeQuery($query);
        if ($result != 0) {
            $result = array('success' => 1);
            return $result;
        }
    }

    public function deleteAnimal()
    {
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $query = "delete from animals where id=" . $id;
            $dbcontroller = new DBController();
            $result = $dbcontroller->executeQuery($query);
            if ($result != 0) {
                $result = array('success' => 1);
                return $result;
            }
        }
    }

    public function searchAnimalById()
    {
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $query = 'SELECT * FROM animals WHERE id=' . $id;
        } else {
            $query = 'SELECT * FROM animals';
        }

        $dbcontroller = new DBController();
        $this->animals = $dbcontroller->executeSelectQuery($query);
        return $this->animals;
    }

    public function searchAnimalByName()
    {
        if (isset($_GET['name'])) {
            $name = $_GET['name'];
            $query = "SELECT * FROM animals WHERE name like '%" . $name . "%'";
        } else {
            $query = 'SELECT * FROM animals';
        }

        $dbcontroller = new DBController();
        $this->animals = $dbcontroller->executeSelectQuery($query);
        return $this->animals;
    }
}
