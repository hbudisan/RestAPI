<?php

require_once("Animal.php");

class AnimalRestHandler
{
    function getAllAnimals()
    {
        $animal = new Animal();
        $rawData = $animal->getAllAnimal();

        if (empty($rawData)) {
            $statusCode = 404;
            $rawData = array('error' => 'No animals found');
        } else {
            $statusCode = 200;
        }

        $response = json_encode($rawData);
        echo $response;
    }

    function add()
    {
        $animal = new Animal();
        $rawData = $animal->addAnimal();
        if (empty($rawData)) {
            $statusCode = 404;
            $rawData = array('success' => 0);
        } else {
            $statusCode = 200;
        }

        $response = json_encode($rawData);
        echo $response;
    }

    function editAnimalById()
    {
        $animal = new Animal();
        $rawData = $animal->editAnimal();
        if (empty($rawData)) {
            $status_code = 404;
            $rawData = array('success' => 0);
        } else {
            $status_code = 200;
        }

        $response = json_encode($rawData);
        echo $response;
    }

    function deleteAnimalById()
    {
        $animal = new Animal();
        $rawData = $animal->deleteAnimal();

        if (empty($rawData)) {
            $status_code = 404;
            $rawData = array('success' => 0);
        } else {
            $status_code = 200;
        }

        $response = json_encode($rawData);
        echo $response;
    }

    function searchAnimalById()
    {
        $animal = new Animal();
        $rawData = $animal->searchAnimalById();

        if (empty($rawData)) {
            $status_code = 404;
            $rawData = array('error' => 'No Animal found!');
        } else {
            $status_code = 200;
        }

        $response = json_encode($rawData);
        echo $response;
    }

    function searchAnimalByName()
    {
        $animal = new Animal();
        $rawData = $animal->searchAnimalByName();

        if (empty($rawData)) {
            $status_code = 404;
            $rawData = array('error' => 'No Animal found!');
        } else {
            $status_code = 200;
        }

        $response = json_encode($rawData);
        echo $response;
    }
}
