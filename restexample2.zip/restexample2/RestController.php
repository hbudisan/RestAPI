<?php

require_once("AnimalRestHandler.php");

$page_key = "";
if (isset($_GET["page_key"]))
    $page_key = $_GET["page_key"];

switch ($page_key) {
    case "list":
        $animalRestHandler = new AnimalRestHandler();
        $animalRestHandler->getAllAnimals();
        break;
    case "create":
        $animalRestHandler = new AnimalRestHandler();
        $animalRestHandler->add();
        break;
    case "update":
        $animalRestHandler = new AnimalRestHandler();
        $animalRestHandler->editAnimalById();
        break;
    case "delete":
        $animalRestHandler = new AnimalRestHandler();
        $animalRestHandler->deleteAnimalById();
        break;
    case "search_id":
        $animalRestHandler = new AnimalRestHandler();
        $animalRestHandler->searchAnimalById();
        break;
    case "search_name":
        $animalRestHandler = new AnimalRestHandler();
        $animalRestHandler->searchAnimalByName();
        break;
    case "":
        // 404 : Not Found
        break;
}
